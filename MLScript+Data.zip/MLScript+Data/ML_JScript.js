        // Global variable for selected location
        let selectedLocation = '';

        class MLA_GUI {
            constructor() {
                this.UIFigure = document.getElementById('app');
                this.errorDiv = document.getElementById('error');
                this.CarModelListBox = document.createElement('select');
                this.CarBrandListBox = document.createElement('select');
                this.CarYearofFabricationEditField = document.createElement('input');
                this.CarKilometersEditField = document.createElement('input');
                this.LocationText = document.createElement('label'); // Added
                this.LocationDropdown = document.createElement('select'); // Added
                this.StartButton = document.createElement('button');
                this.PriceEvaluateAppLabel = document.createElement('label');
                this.SellButton = document.createElement('button');
                this.CarsDataAfter = null;
                this.LinearRegressionModel = null;
                this.features = [];
                this.target = [];

                // Global variables for user input and saved prices
                this.selectedBrand = '';
                this.selectedModel = '';
                this.selectedYear = 0;
                this.selectedKilometers = 0;
                this.predictedPrice = 0;

                this.createComponents();
                this.loadCSVData();
            }

            async loadCSVData() {
                try {
                    const response = await fetch('CarsData After.csv');
                    if (!response.ok) {
                        throw new Error('Failed to load CSV file');
                    }
                    const csvData = await response.text();
                    this.CarsDataAfter = this.csvToTable(csvData);
                    this.populateCarBrandListBox();
                } catch (error) {
                    this.showError('Error loading CSV data: ' + error.message);
                }
            }

            csvToTable(csvData) {
                // Convert CSV data to table (array of objects)
                const rows = csvData.trim().split('\n');
                const headers = rows[0].split(',');
                return rows.slice(1).map(row => {
                    const values = row.split(',');
                    const obj = {};
                    headers.forEach((header, index) => {
                        obj[header] = values[index];
                    });
                    return obj;
                });
            }

            populateCarBrandListBox() {
                const brands = Array.from(new Set(this.CarsDataAfter.map(car => car.Brand)));
                this.CarBrandListBox.innerHTML = brands.map(brand => `<option value="${brand}">${brand}</option>`).join('');
                // Populate car models based on the selected brand
                this.updateCarModels();
                // Listen for changes in brand selection
                this.CarBrandListBox.addEventListener('change', () => this.updateCarModels());
            }

            updateCarModels() {
                const selectedBrand = this.CarBrandListBox.value;
                const models = Array.from(new Set(this.CarsDataAfter.filter(car => car.Brand === selectedBrand).map(car => car.Model)));
                this.CarModelListBox.innerHTML = models.map(model => `<option value="${model}">${model}</option>`).join('');
            }

            async trainLinearRegressionModel(userBrand, userModel) {
                // Filter data for the selected model and brand
                const filteredData = this.CarsDataAfter.filter(car => car.Brand === userBrand && car.Model === userModel);

                // Check if there is data to train the model
                if (filteredData.length === 0) {
                    const errorDiv = document.getElementById('error');
                    if (errorDiv) { // Check if the error element exists
                        errorDiv.textContent = 'No data available for training the model.';
                    } else {
                        console.error('No error element found.');
                    }
                    return;
                }

                // Update features and target data
                this.features = filteredData.map(car => [parseInt(car.YearOfFabrication), parseInt(car.Kilometres)]);
                this.target = filteredData.map(car => parseInt(car.PriceEuro));

                // Train the linear regression model
                try {
                    this.LinearRegressionModel = new SimpleLinearRegression();
                    this.LinearRegressionModel.fit(this.features, this.target);
                    console.log("Linear regression model trained successfully.");
                } catch (error) {
                    console.error("Error training linear regression model:", error);
                    const errorDiv = document.getElementById('error');
                    if (errorDiv) { // Check if the error element exists
                        errorDiv.textContent = 'Error training the model. Please try again.';
                    } else {
                        console.error('No error element found.');
                    }
                }
            }

            performPrediction(userBrand, userModel, userYear, userKilometers) {
                // Train the linear regression model if not already trained
                if (!this.LinearRegressionModel) {
                    this.trainLinearRegressionModel(userBrand, userModel);
                }

                // Perform prediction
                const prediction = this.LinearRegressionModel.predict([[userYear, userKilometers]], this.LinearRegressionModel.fit(this.features, this.target));
                this.predictedPrice = Math.floor(prediction[0]/100)*100;

                if (isNaN(this.predictedPrice)) {
                    console.error("Prediction resulted in NaN. Check input data and model.");
                }
                return Math.trunc(prediction[0]);
            }

            async StartButtonPushed() {
                // Clear previous error message
                this.errorDiv.textContent = '';

                // Get user input and update global variables
                this.selectedBrand = this.CarBrandListBox.value;
                this.selectedModel = this.CarModelListBox.value;
                this.selectedYear = parseInt(this.CarYearofFabricationEditField.value);
                this.selectedKilometers = parseInt(this.CarKilometersEditField.value);
                selectedLocation = this.LocationDropdown.value; // Update selected location

                // Validate user input
                if (isNaN(this.selectedYear) || isNaN(this.selectedKilometers) || this.selectedYear < 1970 || this.selectedYear > 2024 || this.selectedKilometers < 0) {
                    this.showError('Please fill in all fields with correct values.');
                    return;
                }

                // Perform prediction
                await this.performPrediction(this.selectedBrand, this.selectedModel, this.selectedYear, this.selectedKilometers);

                // Show prediction result
                this.showPredictionResult();
            }

            sellButtonClicked() {
                // Clear the page
                this.clearPage();

                // Show the car description
                this.showCarDescription();
            }

            clearPage() {
                // Clear page contents
                this.UIFigure.innerHTML = '';
                this.errorDiv.innerHTML = '';
            }

            showPredictionResult() {
                // Clear the page before showing the result
                this.clearPage();

                // Create predicted price labels
                const predictedPriceLabel = document.createElement('label');
                predictedPriceLabel.textContent = 'Predicted Price: ';
                this.UIFigure.appendChild(predictedPriceLabel);
                this.UIFigure.appendChild(document.createElement('br'));

                // Create input field for predicted price
                const predictedPriceInput = document.createElement('input');
                predictedPriceInput.id = 'predictedPrice'; // Add id for reference
                predictedPriceInput.type = 'text';
                predictedPriceInput.value = this.predictedPrice;
                predictedPriceInput.disabled = true;
                this.UIFigure.appendChild(predictedPriceInput);
                this.UIFigure.appendChild(document.createElement('br'));

                // Create button for currency conversion
                const currencyConversionButton = document.createElement('button');
                currencyConversionButton.textContent = 'Convert from EURO to LEI';
                this.UIFigure.appendChild(document.createElement('br'));
                currencyConversionButton.addEventListener('click', () => {
                    if (currencyConversionButton.textContent === 'Convert from EURO to LEI') {
                        const priceInLei = this.predictedPrice * 4.98; // Conversion rate
                        predictedPriceInput.value = priceInLei.toFixed(2);
                        currencyConversionButton.textContent = 'Convert from LEI to EURO';
                    } else {
                        predictedPriceInput.value = this.predictedPrice;
                        currencyConversionButton.textContent = 'Convert from EURO to LEI';
                    }
                });
                this.UIFigure.appendChild(currencyConversionButton);

                // Create "Return to Specs Selection" button
                const returnToSpecsButton = document.createElement('button');
                returnToSpecsButton.textContent = 'RETURN';
                this.UIFigure.appendChild(document.createElement('br'));
                returnToSpecsButton.addEventListener('click', () => {
                    // Clear the page and recreate initial components
                    this.clearPage();
                    this.createComponents();
                });
                this.UIFigure.appendChild(returnToSpecsButton);

                // Create "Sell" button
                this.UIFigure.appendChild(document.createElement('br'));
                this.SellButton.textContent = 'SELL';
                this.SellButton.addEventListener('click', this.sellButtonClicked.bind(this));
                this.UIFigure.appendChild(this.SellButton);
            }

            showCarDescription() {
                // Create label for car stats
                const carStatsLabel = document.createElement('label');
                carStatsLabel.textContent = 'Your Car Stats:';
                this.UIFigure.appendChild(carStatsLabel);
                this.UIFigure.appendChild(document.createElement('br'));

                // Show car brand
                const carBrandLabel = document.createElement('label');
                carBrandLabel.textContent = 'Brand: ' + this.selectedBrand;
                this.UIFigure.appendChild(carBrandLabel);
                this.UIFigure.appendChild(document.createElement('br'));

                // Show car model
                const carModelLabel = document.createElement('label');
                carModelLabel.textContent = 'Model: ' + this.selectedModel;
                this.UIFigure.appendChild(carModelLabel);
                this.UIFigure.appendChild(document.createElement('br'));

                // Show year of fabrication
                const carYearLabel = document.createElement('label');
                carYearLabel.textContent = 'Year of fabrication: ' + this.selectedYear;
                this.UIFigure.appendChild(carYearLabel);
                this.UIFigure.appendChild(document.createElement('br'));

                // Show kilometers
                const carKmLabel = document.createElement('label');
                carKmLabel.textContent = 'Kilometers: ' + this.selectedKilometers;
                this.UIFigure.appendChild(carKmLabel);
                this.UIFigure.appendChild(document.createElement('br'));

                // Show location
                const locationLabel = document.createElement('label');
                locationLabel.textContent = 'Location: ' + selectedLocation;
                this.UIFigure.appendChild(locationLabel);
                this.UIFigure.appendChild(document.createElement('br'));

                // Show predicted price
                const predictedPriceLabel = document.createElement('label');
                predictedPriceLabel.textContent = 'Given price for the car: ' + this.predictedPrice;
                this.UIFigure.appendChild(predictedPriceLabel);
                this.UIFigure.appendChild(document.createElement('br'));

                // Create "Sell Another Car" button
                const sellAnotherButton = document.createElement('button');
                sellAnotherButton.textContent = 'SELL ANOTHER CAR';
                sellAnotherButton.addEventListener('click', () => {
                    // Clear previous components
                    carStatsLabel.remove();
                    carBrandLabel.remove();
                    carModelLabel.remove();
                    carYearLabel.remove();
                    carKmLabel.remove();
                    locationLabel.remove(); // Remove location label
                    predictedPriceLabel.remove();
                    sellAnotherButton.remove();

                    // Recreate initial components
                    this.createComponents();
                });
                this.UIFigure.appendChild(sellAnotherButton);
            }

            createComponents() {
                this.PriceEvaluateAppLabel.textContent = 'Price Evaluate App';
                this.UIFigure.appendChild(this.PriceEvaluateAppLabel);
                this.UIFigure.appendChild(document.createElement('br'));

                const carBrandLabel = document.createElement('label');
                carBrandLabel.textContent = 'Car Brand';
                this.UIFigure.appendChild(carBrandLabel);
                this.UIFigure.appendChild(document.createElement('br'));
                this.UIFigure.appendChild(this.CarBrandListBox);

                const carModelLabel = document.createElement('label');
                carModelLabel.textContent = 'Car Model';
                this.UIFigure.appendChild(document.createElement('br'));
                this.UIFigure.appendChild(carModelLabel);
                this.UIFigure.appendChild(document.createElement('br'));
                this.UIFigure.appendChild(this.CarModelListBox);

                const carYearLabel = document.createElement('label');
                carYearLabel.textContent = 'Car Year of Fabrication';
                this.UIFigure.appendChild(document.createElement('br'));
                this.UIFigure.appendChild(carYearLabel);
                this.UIFigure.appendChild(document.createElement('br'));
                this.UIFigure.appendChild(this.CarYearofFabricationEditField);

                const carKmLabel = document.createElement('label');
                carKmLabel.textContent = 'Car Mileage';
                this.UIFigure.appendChild(document.createElement('br'));
                this.UIFigure.appendChild(carKmLabel);
                this.UIFigure.appendChild(document.createElement('br'));
                this.UIFigure.appendChild(this.CarKilometersEditField);

                // Add Location Text and Dropdown
                const locationLabel = document.createElement('label');
                locationLabel.textContent = 'Location';
                this.UIFigure.appendChild(document.createElement('br'));
                this.UIFigure.appendChild(locationLabel);
                this.UIFigure.appendChild(document.createElement('br'));
                this.UIFigure.appendChild(this.LocationDropdown); // Added

                this.StartButton.textContent = 'ESTIMATE';
                this.StartButton.addEventListener('click', this.StartButtonPushed.bind(this));
                this.UIFigure.appendChild(document.createElement('br'));
                this.UIFigure.appendChild(this.StartButton);
                this.UIFigure.appendChild(document.createElement('br'));
            }

            showError(message) {
                const errorMessage = document.createElement('div');
                errorMessage.textContent = message;
                errorMessage.style.color = 'red';
                this.errorDiv.appendChild(errorMessage);
            }
        }

        class SimpleLinearRegression {
            fit(X, y) {
                const sum_x = X.reduce((acc, val) => acc + val[0], 0);
                const sum_y = y.reduce((acc, val) => acc + val, 0);
                const sum_xy = X.reduce((acc, val, index) => acc + val[0] * y[index], 0);
                const sum_xx = X.reduce((acc, val) => acc + val[0] ** 2, 0);

                const n = X.length;
                const m = (n * sum_xy - sum_x * sum_y) / (n * sum_xx - sum_x ** 2);
                const b = (sum_y - m * sum_x) / n;

                return [b, m]; // Return the coefficients [b, m]
            }

            predict(X, coefficients) {
                if (!Array.isArray(coefficients) || coefficients.length !== 2) {
                    throw new Error("Invalid coefficients provided.");
                }

                return X.map(val => coefficients[0] + val[0] * coefficients[1]); // Fix the prediction calculation
            }
        }

        // Create instance of the MLA_GUI class
        const mlaGui = new MLA_GUI();

        // Populate Location Dropdown
        const locationData = ["Alba", "Arad", "Arges", "Bacau", "Bihor", "Bistrita-Nasaud", "Botosani", "Brasov", "Braila", "Bucuresti", "Buzau", "Caras-Severin", "Calarasi", "Cluj", "Constanta", "Covasna", "Dambovita", "Dolj", "Galati", "Gorj", "Harghita", "Hunedoara", "Ialomita", "Iasi", "Ilfov", "Maramures", "Mehedinti", "Mures", "Neamt", "Olt", "Prahova", "Satu Mare", "Salaj", "Sibiu", "Suceava", "Teleorman", "Timis", "Tulcea", "Vaslui", "Valcea", "Vrancea"];
        const locationDropdown = mlaGui.LocationDropdown;
        locationData.forEach(location => {
            const option = document.createElement('option');
            option.textContent = location;
            locationDropdown.appendChild(option);
        });

        // Append location dropdown to the page
        mlaGui.UIFigure.appendChild(document.createElement('br'));
        mlaGui.UIFigure.appendChild(document.createElement('br'));
        mlaGui.UIFigure.appendChild(locationDropdown); // Modified
    